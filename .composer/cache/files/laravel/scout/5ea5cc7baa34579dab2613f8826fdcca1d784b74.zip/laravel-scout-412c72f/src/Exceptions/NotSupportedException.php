<?php

namespace Laravel\Scout\Exceptions;

class NotSupportedException extends ScoutException
{
    //
}
